# CMUEsports-Website
This project is for building and maintaining a public website for CMU Esports Club.

## Details
This website is built primarily using HTML and CSS with one additional widget using javascript.

## CMU ESPORTS CLUB
A gaming community based in Carnegie Mellon University.
[Join us on Discord: https://https://discord.gg/cmuesports]
